//
//  AppDelegate.h
//  demovi
//
//  Created by APPLE on 2020/1/22.
//  Copyright © 2020 APPLE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow * window;


@end

