//
//  NewViewController.h
//  demovi
//
//  Created by APPLE on 2020/1/22.
//  Copyright © 2020 APPLE. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NewViewController : UIViewController
- (IBAction)playB:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *playB;

@end

NS_ASSUME_NONNULL_END
