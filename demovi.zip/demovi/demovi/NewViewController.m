//
//  NewViewController.m
//  demovi
//
//  Created by APPLE on 2020/1/22.
//  Copyright © 2020 APPLE. All rights reserved.
//

#import "NewViewController.h"
#import "AssetManager.h"

@interface NewViewController ()
@property (nonatomic, strong) AVAsset *asset;

@end

@implementation NewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.asset = [AVAsset assetWithURL:[[NSBundle mainBundle] URLForResource:@"4" withExtension:@"MOV"]];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)playB:(id)sender {
    
        
        [AssetManager compressAsset:self.asset exportPreset:[self assetExportPreset] finish:^(BOOL isSuccess, NSString * _Nonnull exportPath) {

            if (isSuccess) {
                
                NSLog(@"isSuccess");
            }else {
                NSLog(@"!!!错误");


            }
        }];

    }

    - (NSString *)assetExportPreset {
    //    if (self.selectBtn.tag == 0) {
            return AVAssetExportPresetHighestQuality;
    //    }else if (self.selectBtn.tag == 1) {
    //        return AVAssetExportPresetMediumQuality;
    //    }
    //    return AVAssetExportPresetLowQuality;
    }


+ (NSString *)videoOutputPath:(NSString *)fileName {
    NSFileManager *manager = [NSFileManager defaultManager];
    NSString *folderPath = [NSString stringWithFormat:@"%@/video", YPathDocument];
    NSString *outputPath = [NSString stringWithFormat:@"%@/%@.mp4", folderPath, fileName];
    if ([manager fileExistsAtPath:outputPath]) {
        [manager removeItemAtPath:outputPath error:nil];
    }
    
    if (![manager fileExistsAtPath:folderPath]) {
        [manager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return outputPath;
}


@end
