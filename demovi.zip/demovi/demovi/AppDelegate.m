//
//  AppDelegate.m
//  demovi
//
//  Created by APPLE on 2020/1/22.
//  Copyright © 2020 APPLE. All rights reserved.
//

#import "AppDelegate.h"
#import "NewViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate
@synthesize window = _window;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    
    NewViewController *new=[[NewViewController alloc]initWithNibName:@"NewViewController" bundle:nil];
    
    
//    Dog_Egg_VideoProceViewController *bog=[[Dog_Egg_VideoProceViewController alloc]init];
    UINavigationController *na=[[UINavigationController alloc]initWithRootViewController:new];
    
    self.window.rootViewController = na;
    [self.window makeKeyWindow];

    
    return YES;
}


//#pragma mark - UISceneSession lifecycle
//
//
//- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
//    // Called when a new scene session is being created.
//    // Use this method to select a configuration to create the new scene with.
//    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
//}
//
//
//- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
//    // Called when the user discards a scene session.
//    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
//    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
//}


@end
