//
//  AssetManager.h
//  demovi
//
//  Created by APPLE on 2020/1/22.
//  Copyright © 2020 APPLE. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <Photos/Photos.h>
#define YPathDocument [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) firstObject]

#define YPathCache [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject]


typedef void(^ExportFinishBlock)(BOOL isSuccess, NSString * _Nonnull exportPath);

NS_ASSUME_NONNULL_BEGIN

@interface AssetManager : NSObject
+ (void)compressAsset:(AVAsset *)asset exportPreset:(NSString *)exportPreset finish:(ExportFinishBlock)finishBlock;

@end

NS_ASSUME_NONNULL_END
