//
//  AssetManager.m
//  demovi
//
//  Created by APPLE on 2020/1/22.
//  Copyright © 2020 APPLE. All rights reserved.
//

#import "AssetManager.h"


@implementation AssetManager

/// 视频压缩
+ (void)compressAsset:(AVAsset *)asset exportPreset:(NSString *)exportPreset finish:(ExportFinishBlock)finishBlock {
    
    NSString *outputPath = [self videoOutputPath:@"compress"];
    unlink([outputPath UTF8String]);
    /// 导出
    AVAssetExportSession *exporter = [[AVAssetExportSession alloc] initWithAsset:asset presetName:exportPreset];
    
    exporter.outputURL = [NSURL fileURLWithPath:outputPath isDirectory:YES];
    
    exporter.outputFileType = AVFileTypeQuickTimeMovie;
    exporter.shouldOptimizeForNetworkUse = YES;
    exporter.timeRange = CMTimeRangeMake(kCMTimeZero, asset.duration);
    [exporter exportAsynchronouslyWithCompletionHandler:^{
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (finishBlock) {
                BOOL isOk = (!exporter.error && exporter.status == AVAssetExportSessionStatusCompleted);
                finishBlock(isOk, outputPath);
                
                if (exporter.error) {
                    NSLog(@"----- %@", exporter.error);
                }
            }
        });
    }];
}

+ (NSString *)videoOutputPath:(NSString *)fileName {
    NSFileManager *manager = [NSFileManager defaultManager];
    //4.MOV
    NSString *folderPath = [NSString stringWithFormat:@"%@/video", YPathDocument];
//    NSString *outputPath = [NSString stringWithFormat:@"%@/%@.mp4", folderPath, fileName];
    
    NSString *outputPath = [NSString stringWithFormat:@"%@/%@.MOV", folderPath, fileName];

    if ([manager fileExistsAtPath:outputPath]) {
        [manager removeItemAtPath:outputPath error:nil];
    }
    
    if (![manager fileExistsAtPath:folderPath]) {
        [manager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return outputPath;
}


@end
